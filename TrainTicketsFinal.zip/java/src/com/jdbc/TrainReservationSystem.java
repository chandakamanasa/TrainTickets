package com.jdbc;



import java.sql.*;
import java.util.Arrays;
import java.util.Scanner;

public class TrainReservationSystem {
    
    // Define constants for the number of seats in a row and in the last row
    private static final int SEATS_IN_ROW = 7;
    private static final int SEATS_IN_LAST_ROW = 3;
    
    
    @Override
	public String toString() {
		return "TrainReservationSystem []";
	}

	// Define a list to store the availability of seats
    private static boolean[] seats = new boolean[80];
    
    // Function to find the consecutive available seats
    private static int findSeats(int numSeats) {
        for (int i = 0; i <= 80 - numSeats; i++) {
            boolean isConsecutive = true;
            for (int j = i; j < i + numSeats; j++) {
                if (!seats[j]) {
                    isConsecutive = false;
                    break;
                }
            }
            if (isConsecutive) {
                return i;
            }
        }
        return -1;
    }
    
    // Function to reserve seats
    private static int[] reserveSeats(int numSeats) throws ClassNotFoundException {
        if (numSeats <= 0) {
            System.out.println("Please enter a valid number of seats.");
            return new int[0];
        } else if (numSeats > 7) {
            System.out.println("Sorry, you cannot reserve more than 7 seats at a time.");
            return new int[0];
        } else {
            int index = findSeats(numSeats);
            if (index == -1) {
                System.out.println("Sorry, there are no consecutive available seats.");
                return new int[0];
            } else {
                for (int i = index; i < index + numSeats; i++) {
                    seats[i] = false;
                }
                int[] reservedSeats = new int[numSeats];
                for (int i = 0; i < numSeats; i++) {
                    reservedSeats[i] = index + i + 1;
                }
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    // Open a connection to the database
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sys", "root", "Jan@5633");
                    // Insert the reservation details into the database
                    String reservedSeatsStr = "";
                    for (int i = 0; i < reservedSeats.length; i++) {
                        reservedSeatsStr += reservedSeats[i];
                        if (i < reservedSeats.length - 1) {
                            reservedSeatsStr += ",";
                        }
                    }
                    String query = "INSERT INTO reservations (seat_numbers) VALUES (?)";
                    PreparedStatement pstmt = conn.prepareStatement(query);
                    pstmt.setString(1, reservedSeatsStr);
                    pstmt.executeUpdate();
                    // Close the connection to the database
                    conn.close();
                } catch (SQLException e) {
                    System.out.println("An error occurred while connecting to the database: " + e.getMessage());
                }
                System.out.println("The following seats have been reserved for you: " + String.join(", ", Arrays.toString(reservedSeats)));
                return reservedSeats;
            }
        }
    }

	
    
    // Function to display the seats and their availability status
    private static void displaySeats() {
        for (int i = 0; i < 80; i++) {
            if (i % SEATS_IN_ROW == 0) {
                System.out.println();
            }
            if (i % SEATS_IN_ROW == SEATS_IN_LAST_ROW) {
                System.out.print("  ");
            }
            if (seats[i]) {
                System.out.print("O ");
            } else {
                System.out.print("X ");
            }
        }
        System.out.println("\n");
    }
    
    public static void main(String[] args) throws ClassNotFoundException {
        Scanner scanner = new Scanner(System.in);
        // Initialize all seats to available
        for (int i = 0; i < 80; i++) {
            seats[i] = true;
    }
    
    while (true) {
        System.out.println("Welcome to the Train Reservation System");
        System.out.println("----------------------------------------");
        System.out.println("Please select an option:");
        System.out.println("1. Reserve seats");
        System.out.println("2. Display available seats");
        System.out.println("3. Exit");
        
        int option = scanner.nextInt();
        
        switch (option) {
            case 1:
                System.out.println("How many seats do you want to reserve?");
                int numSeats = scanner.nextInt();
                reserveSeats(numSeats);
                break;
                
            case 2:
                displaySeats();
                break;
                
            case 3:
                System.out.println("Thank you for using the Train Reservation System!");
                System.exit(0);
                break;
                
            default:
                System.out.println("Please enter a valid option.");
                break;
        }
    }
    }}

